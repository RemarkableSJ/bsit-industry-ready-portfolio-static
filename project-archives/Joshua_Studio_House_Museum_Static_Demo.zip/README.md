# Joshua's Studio House Museum — Static Presentation Edition

This folder is a **front-end-only presentation build** of the Museum website. It is designed for a professor/employer demonstration, not for accepting orders.

## What works in this edition

- Grand Hall landing page and the three showroom carousels
- Graphite, Canvas, Artisan Artifacts, and Curated collections
- Product cards, filters, item variants, stock labels, and local cart
- Shipping/pickup form demonstration
- Commission request form demonstration
- Browser-local demo history and local stock updates using `localStorage`
- Artwork and product images in `assets/images/`

## Intentionally disabled

- Firebase Authentication / Firestore
- PayMongo and PayPal SDKs / payment processing
- PHP payment endpoints and webhook
- Real order submission, order fulfilment, and administrator order dashboard

A completed cart or commission form only creates a **local demo record in the current browser**. It does not send customer data to a server, process a payment, reserve inventory, or create a real order.

## Run locally

Because this is a static site, you can open `index.html` directly in a modern browser. For a local server, from this folder run:

```bash
python -m http.server 8000
```

Then open `http://localhost:8000`.

## Publish with GitHub Pages

Create a separate repository for this static project, upload the contents of this folder to the repository root, then enable **Settings → Pages → Deploy from a branch → main → / (root)**. The published URL will be a GitHub Pages site. The website uses Tailwind/Lucide/Google Fonts CDN resources, so an internet connection is needed for those visual libraries.

## Reset the demo

Use browser developer tools → Application/Storage → Local Storage and clear these keys:

- `museum_demo_inventory`
- `museum_demo_orders`
- `museum_demo_commissions`
- `cart`

## Important

This static presentation version intentionally does not implement real commerce. Do not tell visitors they can place a genuine order or payment through it.
