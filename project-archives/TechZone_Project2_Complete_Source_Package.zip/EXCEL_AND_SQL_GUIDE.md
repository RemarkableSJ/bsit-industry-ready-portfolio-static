# Excel and MySQL completion guide

## A. Excel workbook

Open `TechZone_Smartphone_Analysis.xlsx`.

### Worksheets
- `Raw_Data`: original source rows are preserved.
- `Cleaned_Data`: 15 actual smartphone records plus formula-driven decision-score columns.
- `Summary`: formula-driven statistics, correlation, and price-tier counts.
- `Brand_Analysis`: formula-driven model counts and average product metrics by brand.
- `Price_Tiers`: count of products in each price category.
- `Summary` also contains four charts.
- `Guide` and `SQL_Guide` explain the workbook and SQL workflow.

### Formula explanation for your defense
- `COUNTA`: counts non-empty product model cells.
- `AVERAGE`: calculates the arithmetic mean.
- `MIN` / `MAX`: find the lowest and highest price.
- `CORREL`: measures the linear relationship between price and customer rating.
- `COUNTIF`: counts products satisfying one condition.
- `COUNTIFS`: counts products satisfying multiple conditions.
- `AVERAGEIF`: calculates an average for one selected brand.
- Decision Score: combines normalized rating (60%) and affordability (40%).

The workbook has been generated as a supporting Excel artifact. Review it, open it in Excel, and capture your own screenshots showing formulas and charts.

## B. MySQL using XAMPP

1. Open `D:\xampp\xampp-control.exe`.
2. Start MySQL.
3. Open `http://localhost/phpmyadmin`.
4. Select the SQL tab.
5. Open `techzone_sql_setup_and_queries.sql` in Notepad or VS Code.
6. Copy the full content into phpMyAdmin's SQL editor and click Go.
7. Select `techzone_analysis` and open `smartphone_products`.
8. Confirm there are 15 rows.
9. Run each query separately if you want individual screenshots of the results.

### SQL query explanations
1. `COUNT(*)`: counts all product records.
2. `GROUP BY Brand` with `AVG(Price)`: calculates average price for each brand.
3. `GROUP BY Brand` with `AVG(Customer_Rating)`: compares average ratings by brand.
4. `WHERE Customer_Rating >= 4.8`: filters highly rated products.
5. `AVG`: calculates average RAM, battery, price, and rating.
6. `CASE`: assigns price categories.
7. `MIN` and `MAX`: identifies least and most expensive products.

### Important integration note
The submitted Streamlit app reads CSV data. The MySQL script is a separate SQL/database demonstration. Do not say that the Python dashboard is connected to MySQL unless you separately implement and test that connection.

## C. Evidence to capture

- Screenshot of `Raw_Data` showing the original data.
- Screenshot of `Cleaned_Data` showing the 15 real product records.
- Screenshot of Excel formulas in the Summary sheet.
- Screenshot of Excel brand-analysis chart.
- Screenshot of Excel price-category chart.
- Screenshot of the MySQL table structure.
- Screenshot of the MySQL table showing 15 records.
- Screenshot of each SQL query and its result.
- Screenshot of the Streamlit dashboard.
- Screenshot of the Streamlit brand, product, relationships, and inventory tabs.
- Screenshot of Jupyter Notebook outputs after running all cells.

Never include passwords, database credentials, API keys, or private customer information in the screenshots.
