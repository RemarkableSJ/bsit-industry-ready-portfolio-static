# Publish TechZone Mobile Store with Streamlit Community Cloud

1. Create a public GitHub repository, e.g. `techzone-mobile-store`.
2. Upload the CONTENTS of this folder to the repository root. Ensure `app.py`, `requirements.txt`, and `smartphones.csv` are at the top level.
3. Open https://share.streamlit.io/ and sign in with GitHub.
4. Choose **Create app**, then select your repository, branch `main`, and file path `app.py`.
5. Select **Deploy**. Community Cloud will create a `*.streamlit.app` URL.
6. Test the filters, charts, compare tab, CSV download, and empty/invalid uploaded CSV handling.

The Streamlit dashboard reads the local CSV in this repository. The supplementary SQL script demonstrates MySQL separately; the current dashboard is not connected to that MySQL database. The source dataset has product data, not transaction/sales history, so the project is not a sales forecasting system.

Official guide: https://docs.streamlit.io/deploy/streamlit-community-cloud/deploy-your-app
