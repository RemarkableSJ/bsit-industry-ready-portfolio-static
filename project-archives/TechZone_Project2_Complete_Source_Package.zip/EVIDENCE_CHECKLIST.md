# Project 2 evidence checklist

Mark each item only after you have personally captured or verified it.

## Python / Streamlit
- [ ] Streamlit application home/dashboard
- [ ] Brand Analysis tab
- [ ] Product Explorer tab
- [ ] Relationships / correlation heatmap
- [ ] Inventory Advisor rankings
- [ ] Assignment Answers tab
- [ ] CSV upload and filtering demonstration
- [ ] Download cleaned CSV demonstration

## Jupyter Notebook
- [ ] Raw CSV inspection showing 29 source rows
- [ ] Data-cleaning cell showing 15 retained products
- [ ] Descriptive statistics output
- [ ] Brand comparison output
- [ ] Price by brand chart
- [ ] Rating by brand chart
- [ ] Price-rating scatter plot
- [ ] Price distribution histogram
- [ ] Correlation heatmap
- [ ] Findings and recommendations

## Microsoft Excel
- [ ] Raw_Data worksheet
- [ ] Cleaned_Data worksheet
- [ ] Summary formulas and results
- [ ] Brand_Analysis calculations
- [ ] Price_Tiers calculation
- [ ] Charts visible in Summary
- [ ] Formula bar screenshot showing formula use

## MySQL
- [ ] Database `techzone_analysis` created
- [ ] Table `smartphone_products` created
- [ ] Table structure screenshot
- [ ] 15 imported products verified
- [ ] COUNT query result
- [ ] Average price by brand query result
- [ ] Average rating by brand query result
- [ ] Highly-rated products query result
- [ ] Summary statistics query result
- [ ] Price-tier query result

## Documentation
- [ ] README reviewed and personalized
- [ ] Limitations explained accurately
- [ ] Excel and SQL guide reviewed
- [ ] GitHub repository created or updated (if required)
- [ ] Source code committed
- [ ] Evidence folder organized

**Scope reminder:** The dataset has product specifications, prices, and customer ratings. It does not provide sales transactions, units sold, revenue, purchase history, or demand history. Do not claim actual sales forecasting or best-selling products.
