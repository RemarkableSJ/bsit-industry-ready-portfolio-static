# Project 2 Report — TechZone Mobile Store Product and Inventory Analysis

**Student:** Joshua E. Decena  
**Program:** Bachelor of Science in Information Technology  
**Institution:** Datamex College of Saint Adeline  
**Project category:** Data Analysis / Database  
**Application:** TechZone Retail Store Analysis System

## 1. Executive Summary

This project analyzes an instructor-provided smartphone dataset to compare products and brands using technical specifications, listed prices, and customer ratings. A Python-based Streamlit dashboard presents summary statistics, brand comparisons, product details, correlation analysis, and an inventory-screening recommendation.

The project uses Python, Pandas, NumPy, Plotly, Jupyter Notebook, Microsoft Excel, and a supplementary MySQL database demonstration. The supplied data contains 15 actual smartphone records after cleaning. Because the dataset does not contain transaction dates, units sold, revenue, customer purchase histories, or stock movement, the project does not claim to forecast sales or identify actual best-selling products.

## 2. Problem Statement

A retail store evaluating smartphone products needs a structured way to compare products across price, specifications, and customer ratings. When purchasing capital is limited, comparing available products with consistent criteria can support more informed inventory screening.

The project organizes the available product data, calculates descriptive statistics, compares brands, visualizes relationships, and provides a transparent product-screening score.

## 3. Objectives

1. Load and inspect the instructor-provided smartphone dataset.
2. Clean appended summary rows and retain only actual product records.
3. Calculate descriptive statistics for product specifications, prices, and ratings.
4. Compare brands using average price, rating, RAM, and battery capacity.
5. Create charts for price, rating, price distribution, and numerical relationships.
6. Provide interactive filters and product exploration.
7. Calculate a transparent rating-and-affordability score.
8. Support interpretation and business recommendations with evidence.
9. Demonstrate supporting spreadsheet calculations and SQL queries.

## 4. Data Source and Structure

The data source is the smartphone dataset provided by the instructor. It contains the following fields:

- Brand
- Model
- RAM
- Storage
- Processor
- Battery
- Screen Size
- Camera
- Price
- Customer Rating

The original CSV contains 29 data rows after the header. Fifteen rows contain actual smartphone models. Fourteen additional appended rows contain summary labels and values with blank Model fields. These summary rows were excluded from product-level analysis.

After cleaning, 15 valid product records remain, with no missing required product fields and no duplicate Brand–Model combinations.

## 5. Methodology

The project follows these stages:

1. **Problem definition:** identify the need for product comparison and inventory screening.
2. **Data collection:** use the instructor-provided smartphone CSV.
3. **Data understanding:** classify the fields as categorical or numerical.
4. **Data cleaning:** exclude appended summary rows, convert numerical columns, and check missing values and duplicate products.
5. **Descriptive analysis:** calculate average, minimum, and maximum values.
6. **Brand analysis:** compare average brand price, rating, RAM, and battery.
7. **Visualization:** create bar charts, a histogram, a scatter plot, and a correlation heatmap.
8. **Interpretation:** explain what the results indicate and what they cannot prove.
9. **Recommendation:** use the analysis to create a product-screening shortlist.

## 6. Results

| Measure | Result |
|---|---:|
| Valid smartphone records | 15 |
| Number of brands | 10 |
| Average RAM | 11.47 GB |
| Average battery | 5,212.2 mAh |
| Average price | ₱41,256.67 |
| Lowest price | ₱17,990 |
| Highest price | ₱76,990 |
| Average customer rating | 4.73 / 5 |
| Price-rating correlation | +0.896 |
| Affordable products below ₱30,000 | 6 |
| Mid-range products from ₱30,000 to below ₱50,000 | 4 |
| Premium products at or above ₱50,000 | 5 |

Apple has the highest average brand price in the dataset at ₱68,490. Xiaomi has the lowest average brand price at ₱20,490. Honor has the highest average brand rating at 4.90, while Vivo has the lowest at 4.60. Some brands have only one product record, so these brand averages should be interpreted cautiously.

The pairwise price-rating correlation is approximately +0.896. This indicates a strong positive linear association among the 15 listed products. It does not establish that a higher price causes a higher customer rating.

## 7. Recommendation Method

The Streamlit Inventory Advisor calculates an affordability score and a rating score, then combines them:

**Decision Score = (0.60 × Rating Score) + (0.40 × Affordability Score)**

The score is a transparent screening aid chosen for this project. It is not a trained predictive model and does not estimate sales demand.

The top five products under this formula are:

1. Realme GT 7
2. Xiaomi Redmi Note 14 Pro
3. Honor Magic7 Pro
4. Samsung Galaxy S25
5. Google Pixel 9

This shortlist is for further review based on the supplied price and rating data. It is not proof that these products sell the most.

## 8. Excel and Database Work

The supporting Excel workbook contains the original data, cleaned product records, formula-driven summary statistics, brand comparison, price-tier counts, and four charts.

A supplementary MySQL database script creates the `techzone_analysis` database and `smartphone_products` table, inserts the 15 cleaned records, and provides SELECT queries for product count, brand averages, highly rated products, descriptive statistics, and price categories.

The Streamlit application currently reads CSV input. The MySQL database is a separate SQL demonstration and is not represented as an integrated backend for the Python application.

## 9. Limitations

The dataset does not contain:
- sales transaction dates,
- units sold,
- revenue,
- customer purchase histories,
- purchase cost,
- profit margin,
- stock-out history, or
- historical demand.

For this reason, the project cannot calculate actual sales trends, best-selling products, revenue performance, or sales forecasts. The small dataset also limits the extent to which the correlations and brand averages can be generalized.

## 10. Future Improvements

Future versions can incorporate verified transaction records, sales dates, quantities, revenue, purchase cost, margins, and stock-outs. With these fields, the application could support time-based sales analysis, demand forecasting, and inventory quantity planning. A future version could also connect the Streamlit application directly to MySQL rather than relying on CSV input.

## 11. Conclusion

The project demonstrates a complete introductory data-analysis workflow: defining a problem, inspecting and cleaning data, calculating descriptive statistics, comparing groups, visualizing results, interpreting relationships, and preparing recommendations. It also demonstrates Python application development through an interactive Streamlit dashboard, Excel-based supporting analysis, and SQL queries using MySQL.

The strongest conclusion is that the supplied data can support structured product comparison and inventory screening. Additional transaction and stock data would be required before making true sales or demand predictions.
