# TechZone Mobile Store Product and Inventory Analysis

**Developer:** Joshua E. Decena  
**Program:** BS Information Technology (Fourth Year)  
**Institution:** Datamex College of Saint Adeline  
**Project category:** Data Analysis / Database / Inventory Decision Support

## Project scope

This project analyzes the instructor-provided smartphone dataset using Python, Jupyter Notebook, Streamlit, Pandas, NumPy, Plotly, Excel, and a supplementary MySQL implementation.

The source dataset includes smartphone brand, model, specifications, price, and customer rating. It does **not** contain transaction dates, units sold, revenue, customer purchase histories, purchase costs, or stock-out records. Therefore, the application supports **product comparison and inventory screening**. It does not perform actual sales-volume forecasting or prove which products sell best.

## Files included

| File | Purpose |
|---|---|
| `app.py` | Corrected Streamlit interactive dashboard |
| `smartphones.csv` | Cleaned CSV with 15 actual smartphone records; used by the app |
| `smartphones_raw_original.csv` | Original instructor-provided CSV, retained unchanged |
| `TechZone_Data_Analysis_Corrected.ipynb` | Corrected Jupyter Notebook showing data inspection, cleaning, analysis, charts, interpretation, and recommendations |
| `TechZone_Smartphone_Analysis.xlsx` | Excel workbook with raw/cleaned data, formula-driven summary, brand comparison, price categories, and charts |
| `techzone_sql_setup_and_queries.sql` | MySQL database/table setup, inserts for the 15 records, and analysis queries |
| `requirements.txt` | Python package requirements |
| `EVIDENCE_CHECKLIST.md` | Screenshot and submission evidence checklist |
| `EXCEL_AND_SQL_GUIDE.md` | Step-by-step instructions for completing Excel and MySQL evidence |

## Data cleaning

The original CSV has 29 data rows after the header. Fifteen rows are actual smartphone product records. Fourteen appended summary rows have blank `Model` values and are not products.

The cleaned dataset therefore contains:
- 15 valid smartphone records
- 10 brands
- 0 missing values in the required product fields
- 0 duplicate Brand–Model pairs

The notebook demonstrates the cleaning process from `smartphones_raw_original.csv`. The Streamlit app defaults to the cleaned `smartphones.csv` file and also cleans uploaded CSV data.

## Main analysis results

| Measure | Result |
|---|---:|
| Valid product records | 15 |
| Brands | 10 |
| Average RAM | 11.47 GB |
| Average battery | 5,212.2 mAh |
| Average price | PHP 41,256.67 |
| Minimum price | PHP 17,990 |
| Maximum price | PHP 76,990 |
| Average customer rating | 4.73 / 5 |
| Price-rating correlation | +0.896 |
| Affordable (< PHP 30,000) | 6 |
| Mid-range (PHP 30,000 to < PHP 50,000) | 4 |
| Premium (>= PHP 50,000) | 5 |

The +0.896 correlation is a strong positive linear association within this small dataset. It does not prove that a higher price causes a higher customer rating.

## Streamlit application features

1. Dashboard with product count, average price, average rating, highest rating, and price range.
2. Brand analysis comparing model count, price, rating, RAM, and battery.
3. Product Explorer with product specifications and price-rating scatter plot.
4. Relationships tab with correlation heatmap and pairwise correlation.
5. Inventory Advisor using a transparent score of 60% rating and 40% affordability.
6. Assignment Answers tab with the key dataset findings.
7. CSV upload, data cleaning, brand filtering, price filtering, and minimum-rating filtering.
8. Download of cleaned CSV data.

The decision score is a screening aid, not a machine-learning prediction and not a demand forecast.

## Run the Streamlit application on Windows

1. Install Python 3.10 or a compatible newer version.
2. Extract this folder.
3. Open Command Prompt in this folder.
4. Create a virtual environment (recommended):

   ```bat
   python -m venv .venv
   .venv\Scripts\activate
   ```

5. Install dependencies:

   ```bat
   pip install -r requirements.txt
   ```

6. Run the app:

   ```bat
   streamlit run app.py
   ```

7. Open the local URL printed by Streamlit, usually `http://localhost:8501`.

`smartphones.csv` must remain in the same folder as `app.py` for default loading. You can also upload a CSV using the sidebar.

## Open the Jupyter Notebook

1. Install requirements:

   ```bat
   pip install -r requirements.txt
   ```

2. Start Jupyter:

   ```bat
   jupyter notebook
   ```

3. Open `TechZone_Data_Analysis_Corrected.ipynb`.
4. Run all cells from top to bottom.

The notebook reads `smartphones_raw_original.csv` in the same folder to demonstrate the cleaning process.

## MySQL / SQL evidence

The Streamlit app itself reads a CSV file. The SQL script is a separate database demonstration to satisfy the course requirement to use SQL or a database alongside Excel/Google Sheets, charts, and interpretation.

To execute it using XAMPP:
1. Start MySQL in XAMPP.
2. Open `http://localhost/phpmyadmin`.
3. Open the SQL tab.
4. Open `techzone_sql_setup_and_queries.sql` in a text editor.
5. Copy the entire SQL script into phpMyAdmin's SQL editor and execute it.
6. Verify that `techzone_analysis.smartphone_products` contains 15 rows.
7. Run the included SELECT queries and save screenshots of the results.

The script uses `CREATE TABLE IF NOT EXISTS` and `INSERT ... ON DUPLICATE KEY UPDATE`; it is designed to create or refresh these product records without dropping the database.

## Excel evidence

Open `TechZone_Smartphone_Analysis.xlsx`. It contains:
- `Guide`
- `Raw_Data`
- `Cleaned_Data`
- `Summary`
- `Brand_Analysis`
- `Price_Tiers`
- `Chart_Data`
- `SQL_Guide`

The Summary, Brand_Analysis, Price_Tiers, and Cleaned_Data worksheets use formulas. Excel may recalculate these formulas when opening the workbook. Review the formulas and be ready to explain `AVERAGE`, `MIN`, `MAX`, `COUNTIF`, `COUNTIFS`, `AVERAGEIF`, and `CORREL`.

## Project limitations and future improvements

Because the source file has no transaction history or stock movement:
- Do not claim that the project identifies actual best-selling models.
- Do not claim that it predicts sales or demand.
- Do not claim that a model should be ordered in a specific quantity.
- Do not infer customer behavior beyond the supplied rating and product fields.

Future improvements include adding verified transaction data (dates, quantities sold, revenue, purchase cost, margins, and stock-outs), building time-based sales analysis, and integrating a relational database into the app if required.

## Academic honesty and evidence

Capture your own screenshots while running the app, Excel workbook, notebook, and MySQL queries. Do not present sample screenshots or unexecuted steps as completed tests. Explain the limits of the source dataset during your project defense.
