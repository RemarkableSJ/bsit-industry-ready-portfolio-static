-- TechZone Project 2: MySQL setup and analysis queries
-- Source: instructor-provided smartphones CSV after cleaning
-- 15 valid smartphone product records; 14 appended summary rows excluded.
-- This is a supplementary SQL/database demonstration. The Streamlit app reads CSV.

CREATE DATABASE IF NOT EXISTS techzone_analysis
  CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE techzone_analysis;

CREATE TABLE IF NOT EXISTS smartphone_products (
    Brand VARCHAR(50) NOT NULL,
    Model VARCHAR(100) NOT NULL,
    RAM DECIMAL(5,2) NOT NULL,
    Storage INT NOT NULL,
    Processor VARCHAR(120) NOT NULL,
    Battery INT NOT NULL,
    Screen_Size DECIMAL(4,2) NOT NULL,
    Camera INT NOT NULL,
    Price DECIMAL(10,2) NOT NULL,
    Customer_Rating DECIMAL(3,2) NOT NULL,
    PRIMARY KEY (Brand, Model),
    CONSTRAINT chk_price_positive CHECK (Price > 0),
    CONSTRAINT chk_rating_range CHECK (Customer_Rating >= 0 AND Customer_Rating <= 5)
) ENGINE=InnoDB;

-- Insert / refresh the 15 cleaned product records.
INSERT INTO smartphone_products
    (Brand, Model, RAM, Storage, Processor, Battery, Screen_Size, Camera, Price, Customer_Rating)
VALUES
    ('Samsung', 'Galaxy A56', 8, 256, 'Exynos 1480', 5000, 6.6, 50, 23990.0, 4.6),
    ('Samsung', 'Galaxy S25', 12, 512, 'Snapdragon 8 Elite', 5000, 6.8, 200, 69990.0, 4.9),
    ('Apple', 'iPhone 16', 8, 256, 'A18', 3561, 6.1, 48, 59990.0, 4.8),
    ('Apple', 'iPhone 16 Pro', 8, 512, 'A18 Pro', 3582, 6.3, 48, 76990.0, 4.9),
    ('Xiaomi', 'Redmi Note 14 Pro', 8, 256, 'Dimensity 7300', 5500, 6.67, 200, 18990.0, 4.7),
    ('Xiaomi', 'Poco X7', 12, 512, 'Snapdragon 7s Gen 3', 5110, 6.67, 64, 21990.0, 4.6),
    ('Realme', 'Realme 14 Pro', 12, 256, 'Dimensity 7300', 6000, 6.7, 50, 17990.0, 4.5),
    ('Realme', 'GT 7', 12, 512, 'Snapdragon 8 Gen 3', 5500, 6.78, 50, 32990.0, 4.8),
    ('Oppo', 'Reno 13', 12, 256, 'Dimensity 8350', 5600, 6.59, 50, 28990.0, 4.6),
    ('Oppo', 'Find X8', 16, 512, 'Dimensity 9400', 5630, 6.8, 50, 54990.0, 4.8),
    ('Vivo', 'V50', 12, 256, 'Snapdragon 7 Gen 3', 6000, 6.77, 50, 27990.0, 4.6),
    ('Honor', 'Magic7 Pro', 16, 512, 'Snapdragon 8 Elite', 5850, 6.8, 200, 63990.0, 4.9),
    ('Nothing', 'Phone 3', 12, 256, 'Snapdragon 8s Gen 4', 5150, 6.7, 50, 35990.0, 4.7),
    ('Google', 'Pixel 9', 12, 256, 'Tensor G4', 4700, 6.3, 50, 49990.0, 4.8),
    ('Motorola', 'Edge 60 Pro', 12, 512, 'Dimensity 8350', 6000, 6.7, 50, 33990.0, 4.7)
ON DUPLICATE KEY UPDATE
    RAM = VALUES(RAM),
    Storage = VALUES(Storage),
    Processor = VALUES(Processor),
    Battery = VALUES(Battery),
    Screen_Size = VALUES(Screen_Size),
    Camera = VALUES(Camera),
    Price = VALUES(Price),
    Customer_Rating = VALUES(Customer_Rating);

-- QUERY 1: Verify the number of imported products (expected: 15).
SELECT COUNT(*) AS Total_Products FROM smartphone_products;

-- QUERY 2: Compare average price by brand.
SELECT Brand, COUNT(*) AS Models, ROUND(AVG(Price), 2) AS Average_Price
FROM smartphone_products
GROUP BY Brand
ORDER BY Average_Price DESC;

-- QUERY 3: Compare average rating by brand.
SELECT Brand, COUNT(*) AS Models, ROUND(AVG(Customer_Rating), 2) AS Average_Rating
FROM smartphone_products
GROUP BY Brand
ORDER BY Average_Rating DESC;

-- QUERY 4: Find products rated 4.8 or higher.
SELECT Brand, Model, Price, Customer_Rating
FROM smartphone_products
WHERE Customer_Rating >= 4.8
ORDER BY Customer_Rating DESC, Price ASC;

-- QUERY 5: Calculate key dataset averages.
SELECT
    ROUND(AVG(RAM), 2) AS Average_RAM_GB,
    ROUND(AVG(Battery), 1) AS Average_Battery_mAh,
    ROUND(AVG(Price), 2) AS Average_Price_PHP,
    ROUND(AVG(Customer_Rating), 2) AS Average_Rating
FROM smartphone_products;

-- QUERY 6: Classify products into price tiers.
SELECT
    CASE
        WHEN Price < 30000 THEN 'Affordable (< PHP 30,000)'
        WHEN Price < 50000 THEN 'Mid-range (PHP 30,000 to < PHP 50,000)'
        ELSE 'Premium (>= PHP 50,000)'
    END AS Price_Tier,
    COUNT(*) AS Product_Count
FROM smartphone_products
GROUP BY Price_Tier
ORDER BY MIN(Price);

-- QUERY 7: Find the least expensive and most expensive products.
SELECT Brand, Model, Price
FROM smartphone_products
WHERE Price = (SELECT MIN(Price) FROM smartphone_products)
   OR Price = (SELECT MAX(Price) FROM smartphone_products);

-- Scope reminder: the source file has no transaction dates, units sold, or revenue.
-- These queries support product and price/rating analysis, not sales forecasting.
