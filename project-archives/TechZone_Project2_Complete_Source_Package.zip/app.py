import streamlit as st
import pandas as pd
import numpy as np
import plotly.express as px

st.set_page_config(
    page_title="TechZone Product and Inventory Analysis",
    page_icon="📱",
    layout="wide"
)

REQUIRED = [
    "Brand", "Model", "RAM", "Storage", "Processor", "Battery",
    "Screen Size", "Camera", "Price", "Customer Rating"
]
NUMERIC_COLUMNS = [
    "RAM", "Storage", "Battery", "Screen Size",
    "Camera", "Price", "Customer Rating"
]


@st.cache_data
def read_data(uploaded_file=None):
    """Read either the default cleaned CSV or a user-uploaded CSV."""
    if uploaded_file is None:
        return pd.read_csv("smartphones.csv")
    return pd.read_csv(uploaded_file)


def validate_columns(df):
    """Return required column names that are absent from the input."""
    return [column for column in REQUIRED if column not in df.columns]


def clean_data(raw_df):
    """
    Keep actual product records and validate numeric fields.
    The instructor's original CSV has 14 appended summary rows with blank Model.
    """
    df = raw_df.copy()
    original_rows = len(df)

    # Remove non-product rows (summary rows have a blank Model).
    df["Model"] = df["Model"].astype("string").str.strip()
    df["Brand"] = df["Brand"].astype("string").str.strip()
    df = df[
        df["Model"].notna()
        & df["Model"].ne("")
        & df["Brand"].notna()
        & df["Brand"].ne("")
    ].copy()

    # Convert numerical values safely; invalid text becomes missing.
    for column in NUMERIC_COLUMNS:
        df[column] = pd.to_numeric(df[column], errors="coerce")

    # Exclude rows with missing required values.
    df = df.dropna(subset=REQUIRED).copy()

    # Apply basic validity checks.
    df = df[(df["Price"] > 0) & df["Customer Rating"].between(0, 5)].copy()

    # Avoid counting the same product record more than once.
    df = df.drop_duplicates(subset=["Brand", "Model"]).reset_index(drop=True)

    removed_rows = original_rows - len(df)
    return df, original_rows, removed_rows


def money(value):
    return f"₱{value:,.2f}"


def price_tier(price):
    if price < 30000:
        return "Affordable (< ₱30k)"
    if price < 50000:
        return "Mid-range (₱30k–< ₱50k)"
    return "Premium (≥ ₱50k)"


def recommendation_table(df):
    """A transparent product-screening score, not a demand forecast."""
    out = df.copy()
    p_min, p_max = out["Price"].min(), out["Price"].max()
    r_min, r_max = out["Customer Rating"].min(), out["Customer Rating"].max()

    if p_max == p_min:
        out["Affordability Score"] = 1.0
    else:
        out["Affordability Score"] = 1 - (
            (out["Price"] - p_min) / (p_max - p_min)
        )

    if r_max == r_min:
        out["Rating Score"] = 1.0
    else:
        out["Rating Score"] = (
            (out["Customer Rating"] - r_min) / (r_max - r_min)
        )

    out["Decision Score"] = (
        0.60 * out["Rating Score"] + 0.40 * out["Affordability Score"]
    )
    out["Price Tier"] = out["Price"].apply(price_tier)

    median_price = out["Price"].median()
    average_price = out["Price"].mean()
    out["Action"] = np.where(
        (out["Customer Rating"] >= 4.8) & (out["Price"] <= median_price),
        "Prioritize",
        np.where(
            (out["Customer Rating"] >= 4.7) & (out["Price"] <= average_price),
            "Consider",
            np.where(
                out["Customer Rating"] >= 4.8,
                "Selective / premium",
                "Monitor"
            )
        )
    )

    return out.sort_values(
        ["Decision Score", "Customer Rating", "Price"],
        ascending=[False, False, True]
    )


st.title("📱 TechZone Mobile Store Product and Inventory Analysis")
st.caption(
    "Interactive analysis of the instructor-provided smartphone dataset. "
    "This application evaluates products, prices, specifications, and ratings."
)

with st.sidebar:
    st.header("Controls")
    uploaded = st.file_uploader(
        "Upload a CSV",
        type=["csv"],
        help="The CSV must contain the ten required smartphone fields."
    )

    try:
        raw_df = read_data(uploaded)
    except FileNotFoundError:
        st.error(
            "The default smartphones.csv file was not found. "
            "Place it in the same folder as app.py or upload a CSV."
        )
        st.stop()
    except Exception as exc:
        st.error(f"Unable to read the CSV file: {exc}")
        st.stop()

    missing_columns = validate_columns(raw_df)
    if missing_columns:
        st.error(
            "Missing required columns: " + ", ".join(missing_columns)
        )
        st.stop()

    df, original_rows, removed_rows = clean_data(raw_df)
    st.caption(
        f"Rows received: {original_rows} | "
        f"Valid products: {len(df)} | Removed/ignored rows: {removed_rows}"
    )

    if df.empty:
        st.error("No valid smartphone records remain after cleaning.")
        st.stop()

    brands = sorted(df["Brand"].dropna().unique().tolist())
    selected_brands = st.multiselect(
        "Brand filter",
        brands,
        default=brands
    )

    minimum_price = float(df["Price"].min())
    maximum_price = float(df["Price"].max())
    if minimum_price < maximum_price:
        price_range = st.slider(
            "Price range (PHP)",
            min_value=int(minimum_price),
            max_value=int(maximum_price),
            value=(int(minimum_price), int(maximum_price)),
            step=1000
        )
    else:
        price_range = (int(minimum_price), int(maximum_price))
        st.caption(f"All products have the same price: {money(minimum_price)}")

    minimum_rating = st.slider(
        "Minimum customer rating",
        min_value=0.0,
        max_value=5.0,
        value=float(df["Customer Rating"].min()),
        step=0.1
    )

filtered = df[
    df["Brand"].isin(selected_brands)
    & df["Price"].between(price_range[0], price_range[1])
    & (df["Customer Rating"] >= minimum_rating)
].copy()

if filtered.empty:
    st.warning("No products match the selected filters. Adjust the sidebar filters.")
    st.stop()

# Key performance indicators
st.subheader("Overview")
k1, k2, k3, k4, k5 = st.columns(5)
k1.metric("Products", len(filtered))
k2.metric("Average price", money(filtered["Price"].mean()))
k3.metric("Average rating", f"{filtered['Customer Rating'].mean():.2f} / 5")
k4.metric("Highest rating", f"{filtered['Customer Rating'].max():.1f} / 5")
k5.metric(
    "Price range",
    f"{money(filtered['Price'].min())} – {money(filtered['Price'].max())}"
)

st.info(
    "Dataset limitation: the supplied file contains product specifications, "
    "prices, and customer ratings. It does not contain transaction dates, "
    "units sold, revenue, customer purchase histories, or demand history. "
    "Therefore, this system provides product comparison and inventory "
    "screening recommendations—not a true sales-volume forecast."
)

tabs = st.tabs([
    "Dashboard",
    "Brand Analysis",
    "Product Explorer",
    "Relationships",
    "Inventory Advisor",
    "Assignment Answers"
])

with tabs[0]:
    st.subheader("Average price by brand")
    brand_price = (
        filtered.groupby("Brand", as_index=False)["Price"]
        .mean()
        .sort_values("Price", ascending=False)
    )
    fig = px.bar(
        brand_price,
        x="Brand",
        y="Price",
        title="Average Smartphone Price by Brand",
        labels={"Price": "Average Price (PHP)"}
    )
    fig.update_layout(xaxis_tickangle=-45)
    st.plotly_chart(fig, use_container_width=True)

    st.subheader("Average customer rating by brand")
    brand_rating = (
        filtered.groupby("Brand", as_index=False)["Customer Rating"]
        .mean()
        .sort_values("Customer Rating", ascending=False)
    )
    fig = px.bar(
        brand_rating,
        x="Brand",
        y="Customer Rating",
        title="Average Customer Rating by Brand",
        labels={"Customer Rating": "Average Rating"}
    )
    fig.update_yaxes(range=[0, 5])
    fig.update_layout(xaxis_tickangle=-45)
    st.plotly_chart(fig, use_container_width=True)

    st.subheader("Price distribution")
    fig = px.histogram(
        filtered,
        x="Price",
        nbins=5,
        title="Distribution of Smartphone Prices",
        labels={"Price": "Price (PHP)"}
    )
    st.plotly_chart(fig, use_container_width=True)

with tabs[1]:
    st.subheader("Brand comparison")
    brand_summary = (
        filtered.groupby("Brand")
        .agg(
            Models=("Model", "count"),
            Average_Price=("Price", "mean"),
            Average_Rating=("Customer Rating", "mean"),
            Average_RAM=("RAM", "mean"),
            Average_Battery=("Battery", "mean")
        )
        .reset_index()
    )
    st.dataframe(
        brand_summary.style.format({
            "Average_Price": "₱{:,.2f}",
            "Average_Rating": "{:.2f}",
            "Average_RAM": "{:.2f}",
            "Average_Battery": "{:,.1f}"
        }),
        use_container_width=True
    )
    st.markdown(
        "Compare price and rating together. A high average price does not "
        "automatically justify purchasing more units because the supplied "
        "dataset does not contain actual sales-volume or demand data."
    )

with tabs[2]:
    st.subheader("Product Explorer")
    display = filtered.copy()
    display["Price Tier"] = display["Price"].apply(price_tier)
    display = display.sort_values(
        ["Customer Rating", "Price"],
        ascending=[False, True]
    )
    st.dataframe(display, use_container_width=True)

    st.subheader("Price versus customer rating")
    fig = px.scatter(
        filtered,
        x="Price",
        y="Customer Rating",
        color="Brand",
        hover_name="Model",
        size="RAM",
        title="Relationship Between Price and Customer Rating"
    )
    st.plotly_chart(fig, use_container_width=True)

with tabs[3]:
    st.subheader("Correlation analysis")
    numeric_data = filtered[
        ["RAM", "Storage", "Battery", "Screen Size", "Camera", "Price", "Customer Rating"]
    ]
    correlation_matrix = numeric_data.corr()
    fig = px.imshow(
        correlation_matrix,
        text_auto=".2f",
        aspect="auto",
        title="Correlation Heatmap"
    )
    st.plotly_chart(fig, use_container_width=True)

    if len(filtered) >= 3:
        price_rating_correlation = filtered["Price"].corr(
            filtered["Customer Rating"]
        )
        st.metric(
            "Price ↔ Rating correlation",
            f"{price_rating_correlation:.3f}"
        )
        st.caption(
            "Correlation describes association in the selected data. "
            "It does not prove that price causes customer ratings to change."
        )
    else:
        st.info("At least three records are needed for a useful correlation display.")

with tabs[4]:
    st.subheader("Inventory Advisor")
    st.write(
        "The score is a transparent product-screening aid using "
        "**60% customer rating + 40% price affordability**. "
        "It is not a trained model or a sales forecast."
    )
    recommendations = recommendation_table(filtered)
    top_five = recommendations.head(5).copy()
    top_five.insert(0, "Rank", range(1, len(top_five) + 1))
    st.dataframe(
        top_five[
            [
                "Rank", "Brand", "Model", "Price", "Customer Rating",
                "Price Tier", "Decision Score", "Action"
            ]
        ].style.format({
            "Price": "₱{:,.0f}",
            "Customer Rating": "{:.1f}",
            "Decision Score": "{:.3f}"
        }),
        use_container_width=True
    )

    st.subheader("Suggested business actions")
    median_price = filtered["Price"].median()
    high_rating = filtered[filtered["Customer Rating"] >= 4.8]
    affordable_high_rating = filtered[
        (filtered["Customer Rating"] >= 4.7)
        & (filtered["Price"] <= median_price)
    ]
    premium = filtered[filtered["Price"] >= 50000]

    actions = [
        (
            f"Review high-rated models further: {len(high_rating)} filtered "
            "model(s) have ratings of at least 4.8."
        ),
        (
            f"Review the value segment: {len(affordable_high_rating)} filtered "
            f"model(s) have ratings of at least 4.7 and prices at or below "
            f"the median price of {money(median_price)}."
        ),
        (
            f"Treat premium products selectively: {len(premium)} filtered "
            "model(s) cost ₱50,000 or more."
        ),
        (
            "Use RAM, storage, processor, battery, screen size, and camera "
            "as supporting product-comparison factors."
        ),
        (
            "Collect units sold, revenue, purchase cost, margins, stock-outs, "
            "and sales dates before attempting real demand forecasting or "
            "inventory-quantity optimization."
        )
    ]
    for action in actions:
        st.write(f"• {action}")

with tabs[5]:
    st.subheader("Assignment answers — key results")
    st.markdown(f"**Cleaned dataset size:** {len(df)} products × {len(df.columns)} fields")
    st.markdown(f"**Average RAM:** {df['RAM'].mean():.2f} GB")
    st.markdown(f"**Average battery:** {df['Battery'].mean():,.1f} mAh")
    st.markdown(f"**Average price:** {money(df['Price'].mean())}")
    minimum_product = df.loc[df["Price"].idxmin()]
    maximum_product = df.loc[df["Price"].idxmax()]
    st.markdown(
        f"**Minimum price:** {money(minimum_product['Price'])} — "
        f"{minimum_product['Brand']} {minimum_product['Model']}"
    )
    st.markdown(
        f"**Maximum price:** {money(maximum_product['Price'])} — "
        f"{maximum_product['Brand']} {maximum_product['Model']}"
    )
    st.markdown(
        f"**Average customer rating:** {df['Customer Rating'].mean():.2f} / 5"
    )
    highest_rating = df["Customer Rating"].max()
    highest_models = df.loc[
        df["Customer Rating"] == highest_rating, ["Brand", "Model"]
    ]
    names = ", ".join(
        highest_models["Brand"] + " " + highest_models["Model"]
    )
    st.markdown(f"**Highest-rated models ({highest_rating:.1f}):** {names}")
    correlation = df["Price"].corr(df["Customer Rating"])
    st.markdown(
        f"**Price ↔ rating correlation:** {correlation:.3f}. "
        "This is an association, not evidence of causation."
    )
    st.caption(
        "The results are based on 15 valid product records after removing "
        "14 appended summary rows from the instructor-provided CSV."
    )

# Export cleaned data for transparent reuse.
st.download_button(
    label="Download cleaned smartphone data (CSV)",
    data=df.to_csv(index=False).encode("utf-8"),
    file_name="smartphones_cleaned.csv",
    mime="text/csv"
)
